﻿namespace Estates.Interfaces
{
    public interface IHouse : IEstate
    {
        int Floors { get; set; }
    }
}
